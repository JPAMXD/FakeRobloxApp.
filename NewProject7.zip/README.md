# Fake Roblox Mod Menu (Educativo)

Esta aplicación fue creada **solo con fines educativos**, para demostrar cómo los usuarios pueden ser engañados por apps falsas de “mod menus” y para enseñar sobre **seguridad digital**.

> ⚠️ **Advertencia:**  
> Esta app **no contiene malware ni virus**, y no debe usarse para dañar o asustar a otras personas.

## 🧩 Hecha con
- [Sketchware Pro](https://sketchware.io/)
- Lenguaje: Java (Android)
- Exportado como proyecto Android Studio

## 🗂️ Estructura del proyecto
- `src/` → Código fuente principal  
- `res/` → Recursos (layouts, imágenes, strings, etc.)  
- `AndroidManifest.xml` → Configuración general de la app  

## 📜 Licencia
Este proyecto se publica bajo la [Licencia MIT](LICENSE).

---

**Creado por:** JUAN  
**Año:** 2025